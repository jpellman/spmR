spm_getSPM <- function(SPM){
      i <- 1
      Z <- ifelse(is.na(SPM$xCon[[1]]$Vspm),0,SPM$xCon[[1]]$Vspm)
      # copy of Z and XYZ before masking for later use with FDR
      XYZum <- SPM$XYZ
      Zum <- Z

      ## FWER correction

      if(SPM$thr == "RF"){
	  SPM$u <- spm_uc(SPM$pm,SPM$df,SPM$xCon[[i]]$STAT,SPM$xVol$R,SPM$n)
	  SPM$Z <- ifelse(Z>as.vector(SPM$u),Z,0)

      } else if(SPM$thr == "BF"){
	  SPM$u <- spm_uc(SPM$pm,SPM$df,SPM$xCon[[i]]$STAT,SPM$xVol$R,SPM$n,S=sum(SPM$VM))
	  SPM$Z <- ifelse(Z>as.vector(SPM$u),Z,0)

      } else if(SPM$thr == "UC"){
	  SPM$u <- spm_uc(SPM$pm,SPM$df,SPM$xCon[[i]]$STAT,SPM$xVol$R,SPM$n,S=1)
	  SPM$Z <- ifelse(Z>as.vector(SPM$u),Z,0)
      }


      # find clusters
      minz <- abs(min(SPM$Z[SPM$Z>0]))
      zscores <- ifelse(SPM$Z>0,1+minz+SPM$Z,0)
      SPM$clusters <- spm_max(zscores)

      # calculate mm coordinates
      Mplus <- matrix(rep(NA,4*length(SPM$clusters$A)),nrow=4)
      Mplus[1:3,] <- SPM$clusters$M
      Mplus[4,] <- rep(1,length(SPM$clusters$A))
      XYZmm <- SPM$M%*%Mplus

      # local maxima
      v2r <- 1/prod(SPM$FWHM)
      N <- SPM$clusters$N*v2r
      Z <- SPM$clusters$Z
      A <- SPM$clusters$A


      ## FDR correction

# 	  # peak FDR
# 	      peakFDR <- spm_uc_peakFDR(0.05,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,SPM$n,Zum,XYZum,SPM$u)
# 
# 
# 	  # cluster FDR
# 
# 	      if (STAT == 'T' && n ==1){
# 		  V2R = 1/prod(SPM$FWHM)
# 		  clusterFDR <- spm_uc_clusterFDR(0.05,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,SPM$n,Zum,XYZum,V2R,SPM$u)
# 	    





      SPM
}