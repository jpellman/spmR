spm_u <- function(a,df,STAT){
    if (STAT == 'Z'){u <- qnorm(1-a)
    } else if (STAT == 'T'){u <- qt(1-a,df[2])
    } else if (STAT == 'X'){u <- qchisq(1-a,df[2])
    } else if (STAT == 'F'){u <- qf(1-a,df)
    } else if (STAT == 'P'){u <- a
    } else cat("stat incorrectly specified")
    
    u
}
