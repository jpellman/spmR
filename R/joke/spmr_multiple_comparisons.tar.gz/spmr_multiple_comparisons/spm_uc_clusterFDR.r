spm_uc_clusterFDR <- function(q,df,STAT,R,n,Z,XYZ,V2R,ui){

clusterFDR <- list()

Z <- ifelse(Z>=ui,1,0)
N <- spm_bwlabel(Z)

N <- as.vector(table(N)[2:max(N)]*V2R)

Ps <- c()
Pk <- c()

for(i in 1:length(N)){
    Pk[i] <- spm_P_RF(1,N[i],ui,df,STAT,R,n)[1]
    Ps[i] <- spm_P_RF(1,N[i],ui,df,STAT,R,n)[2]
}

J <- order(Ps)
clusterFDR$Ps <- sort(Ps)

S <- length(clusterFDR$Ps)
cV <- 1
Fi <- (1:S)/S*q/cV

try(I <- max(which(clusterFDR$Ps<=Fi)),silent=TRUE)
if(is.finite(I)){clusterFDR$u <- N[J[I]]/V2R} else {clusterFDR$u <- Inf} 

J <- order(Pk)
Pk <- sort(Pk)
try(I <- max(which(Pk<=q)),silent=TRUE)
if(is.finite(I)){clusterFDR$ue <- N[J[I]]/V2R} else {clusterFDR$ue <- Inf} 

clusterFDR
}