spm_P_clusterFDR <- function(k,df,STAT,R,n,ui,Ps){

spm_P_RF(1,k,ui,df,STAT,R,n)




















}