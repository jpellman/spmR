library(AnalyzeFMRI)

## CALCULATE EULER CHARACTERISTICS

# needed: mask + FWHM

SPM <- list()
SPM$xCon[[1]]$Vspm <-f.read.volume("/home/joke/Documents/Uni/Onderzoek/Software/datasetfMRI_SPMdemo_auditory/test/spmT_0001.img")
SPM$xCon[[1]]$Vspm <- SPM$xCon[[1]]$Vspm[,,,1] 
SPM$VM <- ifelse(SPM$xCon[[1]]$Vspm==0,0,1) #(mask = 1 where there are values)
SPM$FWHM <- c(4.6492,4.6523,4.0339) # calculation not yet implemented

# function for EC, door bepalen points, edges, faces

spm_resels_vol <- function(mask,FWHM){

	xdim <- dim(mask)[1]
	ydim <- dim(mask)[2]
	zdim <- dim(mask)[3]

	Ex <- Ey <- Ez <- Fxy <- Fxz <- Fyz <- C <- 0

	for (i in 1:xdim){
	print(i)
	for (j in 1:ydim){
	for (k in 1:zdim){
	if(mask[i,j,k]==1){
	Ex <- ifelse(mask[i+1,j,k]==1,Ex+1,Ex)
	Ey <- ifelse(mask[i,j+1,k]==1,Ey+1,Ey)
	Ez <- ifelse(mask[i,j,k+1]==1,Ez+1,Ez)

	Fxy <- ifelse(mask[i+1,j,k]==1 && mask[i,j+1,k]==1 && mask[i+1,j+1,k]==1,Fxy+1,Fxy)
	Fxz <- ifelse(mask[i+1,j,k]==1 && mask[i,j,k+1]==1 && mask[i+1,j,k+1]==1,Fxz+1,Fxz)
	Fyz <- ifelse(mask[i,j+1,k]==1 && mask[i,j,k+1]==1 && mask[i,j+1,k+1]==1,Fyz+1,Fyz)

	C <- ifelse(mask[i+1,j,k]==1 && mask[i,j+1,k]==1 && mask[i+1,j+1,k]==1 && mask[i,j,k+1]==1 && mask[i+1,j,k+1]==1 && mask[i,j+1,k+1]==1 && mask[i+1,j+1,k+1]==1,C+1,C)
	}}}}

	P <- sum(mask)
	rx <- 1/FWHM[1]
	ry <- 1/FWHM[2]
	rz <- 1/FWHM[3]

	R0 <- P-(Ex+Ey+Ez)+(Fyz+Fxz+Fxy)-C
	R1 <- (Ex-Fxy-Fxz+C)*rx+(Ey-Fxy-Fyz+C)*ry+(Ez-Fxz-Fyz+C)*rz
	R2 <- (Fxy-C)*rx*ry + (Fxz-C)*rx*rz + (Fyz-C)*ry*rz
	R3 <- C*rx*ry*rz

	Res <- c(R0,R1,R2,R3)
	Res
	}

# calculate

SPM$xVol$R <- spm_resels_vol(SPM$VM,SPM$FWHM) #(count = number of voxels on dim 1 = 79)

## CALCULATE RFT THRESHOLD

# needed: uncorrected significance level, statistic type

SPM$pm <- 0.05
SPM$xCon[[1]]$STAT <- 'T'
SPM$n <- 1

# functions for threshold

spm_uc_RF <- function(a,df,STAT,R,n){
    #find approximate value
    u <- spm_u((a/max(R))^(1/n),df,STAT)
    du <- 1e-6
    #approximate estimate using E{m}
    d <- 1
    while (abs(d)>1e-6)
    {
    p <- spm_P_RF(1,0,u,df,STAT,R,n)[1]
    q <- spm_P_RF(1,0,u+du,df,STAT,R,n)[1]
    d <- (a-p)/((q-p)/du)
    u <- u + d
    }
    #refined estimate using 1-exp(-E{m})
    d <- 1
    while(abs(d)>1e-6)
    {
    p <- spm_P_RF(1,0,u,df,STAT,R,n)[1]
    q <- spm_P_RF(1,0,u+du,df,STAT,R,n)[1]
    d <- (a-p)/((q-p)/du)
    u <- u + d
    }
    u
    }

spm_u <- function(a,df,STAT){
    if (STAT == 'T'){u <- qt(1-a,df[2])}
    u
    }

spm_P_RF <- function(c,k,Z,df,STAT,R,n){
      #get expectations
	  # get EC densities
	  D <- length(R)
	  R <- R[1:D]
	  G <- sqrt(pi)/gamma((1:D)/2)
	  EC <- spm_ECdensity(STAT,Z,df)
	  eps <- 2^ -52
	  for(i in 1:D){
	  EC[i] <- max(EC[i],eps)}
	
	  # corrected p value
	  if(length(EC)>1)    {
	  P.1 <- toeplitz(as.vector(t(EC)*G))
	  P <- P.1
	  if (dim(as.matrix(P.1))[1] == 1)
	  P <- P.1
	  if (dim(as.matrix(P.1))[1] > 1)
	  for(m in 1:(dim(as.matrix(P.1))[1])){
	  for(n in 1:(dim(as.matrix(P.1))[1])){
	  P[m,n] <- ifelse(m>n,0,P.1[m,n])
	  }}
	  P <- P[1,]
	  } else {
	  P <- EC*G^n
	  }
	  EM <- R/G*P
	  Em <- sum(EM)
	  EN <- P[1]*R[D]
	  En <- EN/EM[D]

      # get P(n>k)
	  D <- D-1
	  if (D ==0){p = 1
	  }else{

	      if (STAT=='T'){
		beta <- (gamma(D/2 + 1)/En)^(2/D)
		p <- exp(-beta*(k^(2/D)))}
    }
      # Poisson clumping heuristic (for multiple clusters)
      P <- 1 - spm_Pcdf(c-1,(Em + eps)*p)
      c(P,p)
      }

spm_ECdensity <- function(STAT,t,df){

      t <- t(t)
      EC <- matrix(rep(NA,4),nrow=4)

       if (STAT=="T"){
      v <- df[2]
      a <- 4*log(2)
      b <- exp(log(gamma((v+1)/2)) - log(gamma(v/2)))
      c <- (1+t^2/v)^((1-v)/2)

      EC[1,] <- 1-pt(t,v)
      EC[2,] <- a^(1/2)/(2*pi)*c
      EC[3,] <- a/((2*pi)^(3/2))*c*t/((v/2)^(1/2))*b
      EC[4,] <- a^(3/2)/((2*pi)^2)*c*((v-1)*(t^2)/v-1)
      }
     EC
      }

# calculate

threshold <- spm_uc_RF(SPM$pm,SPM$df,SPM$xCon[[i]]$STAT,SPM$xVol$R,SPM$n)

