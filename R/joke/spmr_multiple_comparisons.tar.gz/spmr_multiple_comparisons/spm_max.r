spm_max <- function(X){

      #binary 3Dvol
      vol <- ifelse(X>0,1,0)

      #connectivity criterion
      cci <- spm_bwlabel(vol)
      num <- length(unique(cci[cci!=0]))

      # local maxima
      Lmax <- spm_get_lm(X)
      Lmax <- ifelse(is.na(Lmax),0,Lmax)

      lista <- list()

      lista$A <- cci[Lmax!=0]
      lista$Z <- SPM$Z[Lmax!=0]
      lista$M <- array(0,dim=c(3,length(lista$A)))

      for(m in 1:3){
	  lista$M[m,] <- SPM$XYZ[,,,m][Lmax!=0]
      }

      help<-as.data.frame(table(cci))$Freq[1:max(cci)+1]

      for(i in 1:length(lista$A)){
	  j <- lista$A[i]
	  lista$N[i] <- help[j]
      }

      lista

}

