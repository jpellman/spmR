spmr_contrasts
function (SPM, consess = list(), delete = 0) 
{
    stopifnot(is.list(consess) && length(consess) > 0)
    for (i in 1:length(consess)) {
        if (is.null(consess[[i]]$type)) {
            if (is.matrix(consess[[i]]$con) && nrow(consess[[i]]$con) > 
                1) {
                consess[[i]]$type <- "tcon"
            }
            else {
                consess[[i]]$type <- "fcon"
            }
        }
        if (is.null(consess[[i]]$sessrep)) {
            consess[[i]]$sessrep <- "none"
        }
    }
    if (delete) {
        SPM$xCon <- NULL
        SPM$xCon <- list()
    }
    for (i in 1:length(consess)) {
        if (consess[[i]]$type == "tcon") {
            name <- consess[[i]]$name
            STAT <- "T"
            con <- consess[[i]]$contrast
            if (!is.matrix(con)) {
                con <- as.matrix(con)
            }
            sessrep <- consess[[i]]$sessrep
        }
        else if (consess[[i]]$type == "fcon") {
            name <- consess[[i]]$name
            STAT <- "F"
            con <- consess[[i]]$contrast
            con <- t(con)
            sessrep <- consess[[i]]$sessrep
        }
        else {
            stop("consess type can only be 'tcon' or 'fcon'")
        }
        if (sessrep != "none") {
            stop("support for multiple sessions not implemented yet!")
            nsession <- length(SPM$Sess)
            if (sessrep == "repl") {
            }
            else if (sessrep == "replna") {
            }
            else if (sessrep == "sess") {
            }
            else if (sessrep == "both") {
            }
        }
        else {
            cons = list(con)
            names = list(name)
        }
        for (k in 1:length(cons)) {
            c <- spm_conman("ParseCon", cons[[k]], SPM$xX$xKXs, 
                STAT)
            DxCon <- spm_FcUtil(action = "Set", name = names[[k]], 
                STAT = STAT, set_action = "c", value = c, sX = SPM$xX$xKXs)
            end <- length(SPM$xCon)
            SPM$xCon[[end + 1]] <- DxCon
            SPM <- spm_contrasts(SPM, length(SPM$xCon))
        }
    }
    SPM
}

spm_contrasts
function (SPM, Ic = 1:length(SPM$xCon)) 
{
    xCon <- SPM$xCon
    if (xCon[[1]]$STAT == "P") {
        Vbeta <- SPM$VCbeta
    }
    else {
        Vbeta <- SPM$Vbeta
        VHp <- SPM$VResMS
    }
    for (ic in Ic) {
        if (is.null(xCon[[ic]]$eidf)) {
            X1o <- spm_FcUtil(action = "X1o", Fc = xCon[[ic]], 
                sX = SPM$xX$xKXs)
            trMV <- spm_SpUtil("trMV", X1o, SPM$xX$V)
            trMVMV <- attr(trMV, "trMVMV")
            attributes(trMV) <- NULL
            xCon[[ic]]$eidf <- trMV^2/trMVMV
        }
        if (is.null(xCon[[ic]]$Vcon)) {
            if (xCon[[ic]]$STAT == "T" || xCon[[ic]]$STAT == 
                "P") {
                if (xCon[[ic]]$STAT == "P" && SPM$PPM$xCon[[ic]]$PSTAT == 
                  "F") {
                  stop("Chi^2 Bayesian inference not implemented yet!")
                }
                else {
                  Q <- which(abs(xCon[[ic]]$c) > 0)
                  V <- Vbeta[Q]
                  for (j in 1:length(Q)) {
                    V[[j]] <- V[[j]] * xCon[[ic]]$c[Q[j]]
                  }
                  xCon[[ic]]$Vcon <- spm_add(V)
                }
            }
            else if (xCon[[ic]]$STAT == "F") {
                h <- spm_FcUtil(action = "Hsqr", Fc = xCon[[ic]], 
                  sX = SPM$xX$xKXs)
                xCon[[ic]]$Vcon <- spm_resss(Vbeta, h, flags = "")
            }
            else {
                stop("unknown STAT in xCon")
            }
        }
        if (is.null(xCon[[ic]]$Vspm) || xCon[[ic]]$STAT == "P") {
            if (xCon[[ic]]$STAT == "T") {
                cB <- xCon[[ic]]$Vcon
                l <- VHp
                VcB <- as.numeric(t(xCon[[ic]]$c) %*% SPM$xX$Bcov %*% 
                  xCon[[ic]]$c)
                Z <- cB/sqrt(l * VcB)
            }
            else if (xCon[[ic]]$STAT == "P") {
                stop("PPM not implemented yet!")
            }
            else if (xCon[[ic]]$STAT == "F") {
                MVM <- xCon[[ic]]$Vcon/trMV
                RVR <- VHp
                Z <- MVM/RVR
            }
            xCon[[ic]]$Vspm <- Z
        }
    }
    SPM$xCon <- xCon
    SPM
}
