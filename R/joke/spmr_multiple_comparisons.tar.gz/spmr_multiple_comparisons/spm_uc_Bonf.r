spm_uc_Bonf <- function(a,df,STAT,S,n){
    spm_u((a/S),df,STAT)^(1/n)
}