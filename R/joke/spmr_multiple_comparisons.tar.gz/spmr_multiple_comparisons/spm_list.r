spm_list <- function(SPM){

      # calculate mm coordinates

      Mplus <- matrix(rep(NA,4*length(SPM$clusters$A)),nrow=4)
      Mplus[1:3,] <- SPM$clusters$M
      Mplus[4,] <- rep(1,length(SPM$clusters$A))
      XYZmm <- SPM$M%*%Mplus

      # set-level p-values

      c <- max(SPM$clusters$A)
      Pc <- round(spm_P_RF(c,SPM$k,SPM$u,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,SPM$n),digits=2)[1]

      # local maxima
      v2r <- 1/prod(SPM$FWHM)
      N <- SPM$clusters$N*v2r

      Z <- SPM$clusters$Z
      A <- SPM$clusters$A

      Pk <- Qc <- Nv <- Pn <- Pu <- Qp <- U <- Ze <- Pz <- Qc <- Qp <- Qu <- XYZmm1 <- XYZmm2 <- XYZmm3 <- U <- c()
      j <- 0
      while(length(Z)>0){
	  j <- j+1
	  U[j] <- max(Z)
	  i <- (1:length(SPM$clusters$Z))[SPM$clusters$Z==U[j]]

	  Pk[j] <- round(spm_P_RF(1,N[i],SPM$u,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,1)[1],digits=3)
	  Pn[j] <- round(spm_P_RF(1,N[i],SPM$u,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,1)[2],digits=3)
	  Nv[j] <- SPM$clusters$N[i]

	  Pz[j] <- round(spm_P_RF(1,0,U[j] ,SPM$df,SPM$xCon[[1]]$STAT,1,1)[1],digits=3)
	  Pu[j] <- round(spm_P_RF(1,0,U[j] ,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,1)[1],digits=3)
	  XYZmm1[j] <- XYZmm[1,i]
	  XYZmm2[j] <- XYZmm[2,i]
	  XYZmm3[j] <- XYZmm[3,i]

# 	  Qc[j] <- spm_P_clusterFDR(N[j],SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,1,SPM$u,QPc)
# 	  Qp[j] <- spm_P_peakFDR(U[j],SPM$df,SPM$xCon[[1]]$STAT,1,QPp)

	  A <- A[!Z==U[j]]
	  Z <- Z[!Z==U[j]]

	  #find Z-values apart in same cluster
	  d <- 1
	  if(length(Z[A==SPM$clusters$A[i]])!=0){				# prob: what if false??? go to next cluster!!
	      while(d<SPM$Num){

		  u <- max(Z[A==SPM$clusters$A[i]])
		  i <- (1:length(SPM$clusters$Z))[SPM$clusters$Z==u]

		  #distance more than Dis?
		  distx <- XYZmm1[j]-XYZmm[1,i]
		  disty <- XYZmm2[j]-XYZmm[2,i]
		  distz <- XYZmm3[j]-XYZmm[3,i]
		  dist <- sqrt(distx^2+disty^2+distz^2)
		  if(dist>SPM$Dis){
		  j <- j+1
		  U[j] <- u
		  # Pk[j] <- ""
		  # Pn[j] <- ""
		  # Nv[j] <- ""

		  Pz[j] <- round(spm_P_RF(1,0,U[j] ,SPM$df,SPM$xCon[[1]]$STAT,1,1)[1],digits=3)
		  Pu[j] <- round(spm_P_RF(1,0,U[j] ,SPM$df,SPM$xCon[[1]]$STAT,SPM$xVol$R,1)[1],digits=3)
		  XYZmm1[j] <- XYZmm[1,i]
		  XYZmm2[j] <- XYZmm[2,i]
		  XYZmm3[j] <- XYZmm[3,i]

		  d<-d+1
		  }
		  A <- A[!Z==u]
		  Z <- Z[!Z==u]

		  if(length(Z[A==SPM$clusters$A[i]])==0){break}

	      }

	      Z <- Z[!A==SPM$clusters$A[i]]
	      A <- A[!A==SPM$clusters$A[i]]
	  }
      }

      U <- round(U,digits=3)
      Pc <- c(Pc,rep(NA,length(Pk)-1)) 
      c <- c(c,rep(NA,length(Pk)-1)) 
      Qp <- rep(NA,length(Pk))
      Qc <- rep(NA,length(Pk))
      Qu  <- rep(NA,length(Pk))
      tabular <- data.frame(Pc,c,Pk, Qc, Nv, Pn, Qp, Qu, Pu, U,Pz,XYZmm1,XYZmm2,XYZmm3)
      SPM$results <- tabular

      SPM
}










