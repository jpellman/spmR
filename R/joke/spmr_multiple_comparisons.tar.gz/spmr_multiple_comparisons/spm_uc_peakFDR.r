spm_uc_peakFDR <- function(q,df,STAT,R,n,Z,XYZ,ui){

peakFDR <- list()
I <- ifelse(Z>ui,1,0)
Z <- spm_max(I)

Eu <- spm_P_RF(1,0,ui,df,STAT,R,n)[3]

Ez <- c()
for(i in 1:length(Z$Z)){
    Ez[i] <- spm_P_RF(1,0,Z$Z[i],df,STAT,R,n)[3]
}

J <- order(Ez/Eu)
peakFDR$Ps <- sort(Ez/Eu)
S <- length(peakFDR$Ps)
cV <- 1
Fi <- (1:S)/S*q/cV

try(I <- max(which(peakFDR$Ps<=Fi)),silent=TRUE)
if(is.finite(I)){peakFDR$u <- Z$Z[J[I]]} else {peakFDR$u <- Inf} 

peakFDR


}