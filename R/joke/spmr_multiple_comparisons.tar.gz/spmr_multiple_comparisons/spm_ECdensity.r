spm_ECdensity <- function(STAT,t,df){

      t <- t(t)
      EC <- matrix(rep(NA,4),nrow=4)

      if (STAT=="Z"){
	  a <- 4*log(2)
	  b <- exp(-t^2/2)

	  EC[1,] <- 1-pnorm(t)
	  EC[2,] <- a^(1/2)/(2*pi)*b
	  EC[3,] <- a/((2*pi)^(3/2))*b*t
	  EC[4,] <- a^(3/2)/((2*pi)^2)*b*(t^2-1)
      
    } else if (STAT=="T"){
	  v <- df[2]
	  a <- 4*log(2)
	  b <- exp(log(gamma((v+1)/2)) - log(gamma(v/2)))
	  c <- (1+t^2/v)^((1-v)/2)

	  EC[1,] <- 1-pt(t,v)
	  EC[2,] <- a^(1/2)/(2*pi)*c
	  EC[3,] <- a/((2*pi)^(3/2))*c*t/((v/2)^(1/2))*b
	  EC[4,] <- a^(3/2)/((2*pi)^2)*c*((v-1)*(t^2)/v-1)

      } else if (STAT=="X"){
	  v <- df[2]
	  a <- (4*log(2))/(2*pi)
	  b <- t^(1/2*(v-1))*exp(-t/2-log(gamma(v/2)))/2^((v-2)/2)

	  EC[1,] <- 1-pchisq(t,v)
	  EC[2,] <- a^(1/2)*b
	  EC[3,] <- a*b*(t-(v-1))
	  EC[4,] <- a^(3/2)*b*(t^2-(2*v-1)*t+(v-1)*(v-2))

      } else if (STAT=="F"){
	  k <- df[2]
	  v <- df[1]
	  a <- (f*log(2))/(2*pi)
	  b <- log(gamma(v/2)) + log(gamma(k/2))

	  EC[1,] <- 1-pf(t,df)
	  EC[2,] <- a^(1/2)*exp(log(gamma((v+k-1)/2))-b)*2^(1/2)*(k*t/v)^(1/2*(k-1))*(1+k*t/v)^(-1/2*(v+k-2))
	  EC[3,] <- a*exp(log(gamma((v+k-2)/2))-b)*(k*t/v)^(1/2*(k-2))*(1+k*t/v)^(-1/2*(v+k-2))*((v-1)*k*t/v-(k-1))
	  EC[4,] <- a^(3/2)*exp(log(gamma(((v+k-3)/2)))-b)*2^(-1/2)*(k*t/v)^(1/2*(k-3))*(1+k*t/v)^(-1/2*(v+k-2))*((v-1)*(v-2)*(k*t/v)^2-2(2*v*k-v-k-1)*(k*t/v)+(k-1)*(k-2))
      } else {cat("STAT incorrectly specified")}

      EC
}
