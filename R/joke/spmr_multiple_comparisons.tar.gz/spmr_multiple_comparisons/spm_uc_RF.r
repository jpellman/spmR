spm_uc_RF <- function(a,df,STAT,R,n){
    #find approximate value
    u <- spm_u((a/max(R))^(1/n),df,STAT)
    du <- 1e-6
    #approximate estimate using E{m}
    d <- 1
    while (abs(d)>1e-6) {
	p <- spm_P_RF(1,0,u,df,STAT,R,n)[1]
	q <- spm_P_RF(1,0,u+du,df,STAT,R,n)[1]
	d <- (a-p)/((q-p)/du)
	u <- u + d
    }
    #refined estimate using 1-exp(-E{m})
    d <- 1
    while(abs(d)>1e-6) {
	p <- spm_P_RF(1,0,u,df,STAT,R,n)[1]
	q <- spm_P_RF(1,0,u+du,df,STAT,R,n)[1]
	d <- (a-p)/((q-p)/du)
	u <- u + d
    }
    u
 }
