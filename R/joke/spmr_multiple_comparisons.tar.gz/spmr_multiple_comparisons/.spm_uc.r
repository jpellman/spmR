spm_uc <- function(a,df,STAT,R,n,S=NULL){
if(!is.null(S))  {
    u <- spm_uc_Bonf(a,df,STAT,S,n)
    } else  {
    u <- spm_uc_RF(a,df,STAT,R,n)
    }
    u
    }
