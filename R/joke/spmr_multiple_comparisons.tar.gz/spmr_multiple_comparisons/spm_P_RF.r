spm_P_RF <- function(c,k,Z,df,STAT,R,n){
#get expectations
    # get EC densities
    D <- length(R)
    R <- R[1:D]
    G <- sqrt(pi)/gamma((1:D)/2)
    EC <- spm_ECdensity(STAT,Z,df)
    eps <- 2^ -52
    for(i in 1:D){
    EC[i] <- max(EC[i],eps)}
   
    # corrected p value
    if(length(EC)>1)    {
    P.1 <- toeplitz(as.vector(t(EC)*G))
    P <- P.1
    if (dim(as.matrix(P.1))[1] == 1)
    P <- P.1
    if (dim(as.matrix(P.1))[1] > 1)
    for(m in 1:(dim(as.matrix(P.1))[1])){
    for(n in 1:(dim(as.matrix(P.1))[1])){
    P[m,n] <- ifelse(m>n,0,P.1[m,n])
    }}
    P <- P[1,]
    } else {
    P <- EC*G^n
    }
    EM <- R/G*P
    Ec <- sum(EM)
    EN <- P[1]*R[D]
    Ek <- EN/EM[D]

# get P(n>k)
    D <- D-1
    if (D ==0){p = 1
    }else{

	if (STAT=='Z'){
	  beta <- (gamma(D/2 + 1)/Ek)^(2/D)
	  p <- exp(-beta*(k^(2/D)))

	} else if (STAT=='T'){
	  beta <- (gamma(D/2 + 1)/Ek)^(2/D)
	  p <- exp(-beta*(k^(2/D)))

	} else if (STAT=='X'){
	  beta <- (gamma(D/2 + 1)/Ek)^(2/D)
	  p <- exp(-beta*(k^(2/D)))

	} else if (STAT=='F'){
	  beta <- (gamma(D/2 + 1)/Ek)^(2/D)
	  p <- exp(-beta*(k^(2/D)))

	} else cat("STAT incorrectly specified")
    }

    # Poisson clumping heuristic (for multiple clusters)
    P <- 1 - ppois(c-1,(Ec + eps)*p)
    c(P,p,Ec,Ek)

}
