spm_uc_FDR <- function(q,df,STAT,n,Vs,Vm=NULL){
     if (sum(c(!is.null(q),!is.null(df),!is.null(STAT),!is.null(n),!is.null(Vs),!is.null(Vm)))<6){Vm <- c()}
cV <- 1
if (is.array(Vs)){
Ts <- as.vector(Vs[!is.na(Vs)])    
} 
Ts <- sort(Ts,decreasing=TRUE)

      if (STAT=="Z"){Ps <- (1-pnorm(Ts))^n}
      if (STAT=="T"){Ps <- (1-pt(Ts,df[2]))^n}
      if (STAT=="X"){Ps <- (1-pchisq(Ts,df[2]))^n}
      if (STAT=="F"){Ps <- (1-pf(Ts,df))^n
      } else {Ps <- Ts}
      S <- length(Ps[!is.na(Ps)])

      # FDR inequality
      Fi <- c(1:S)/S*q/cV
     
      # find threshold
      I <- length(which(Ps<=Fi))
      if (length(I) == 0){
	    u <- ifelse(STAT == 'P',0,Inf)
      } else {
	    if(is.array(Ts)){u <- Ts[I]
	    } else {
	    if(STAT=='Z'){u <- qnorm(1-Ps[I]^(1/n))}
	    if(STAT=='T'){u <- qt(1-Ps[I]^(1/n),df[2])}
	    if(STAT=='X'){u <- qchisq(1-Ps[I]^(1/n),df[2])}
	    if(STAT=='F'){u <- qf(1-Ps[I]^(1/n),df)}
	    if(STAT=='P'){u <- Ps[I]}}}    
}