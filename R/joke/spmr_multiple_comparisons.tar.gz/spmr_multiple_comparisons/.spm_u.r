spm_u <- function(a,df,STAT){
    if (STAT == 'Z'){u <- qnorm(1-a)}
    if (STAT == 'T'){u <- qt(1-a,df[2])}
    if (STAT == 'X'){u <- qchisq(1-a,df[2])}
    if (STAT == 'F'){u <- qf(1-a,df)}
    if (STAT == 'P'){u <- a}
    u
}
