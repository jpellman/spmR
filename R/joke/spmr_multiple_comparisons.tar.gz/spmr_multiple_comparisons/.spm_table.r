spm_table <- function(SPM){
    results <- SPM$results

    cat("STATISTICS: P-VALUES ADJUSTED FOR SEARCH VOLUME\n")
    cat("===================================================================================================================================\n")
    cat("   set-level    |             cluster-level             |                 peak-level                 |             mm              \n")
    cat("----------------|---------------------------------------|--------------------------------------------|-----------------------------\n")
    cat(" p        c     |    pFWE      qFDR       k      pUnc   |   pFWE       qFDR       T          pUnc    |       X        Y        Z   \n")
    cat("----------------|---------------------------------------|--------------------------------------------|-----------------------------\n")

    results[is.na(results)] <- ""
    for(i in 1:length(results$Pc)){
	if(results$U[i]>10){
	    cat(results$Pc[i],"\t",results$c[i],"\t|\t",results$Pk[i],"\t",results$Qc[i],"\t",results$Nv[i],"\t",results$Pn[i],"\t|\t",results$Pu[i],"\t",results$Qp[i],"\t",results$U[i],"\t",results$Pz[i],"\t|\t",results$XYZmm1[i],"\t",results$XYZmm2[i],"\t",results$XYZmm3[i],"\n")
	}else{
	    cat(results$Pc[i],"\t",results$c[i],"\t|\t",results$Pk[i],"\t",results$Qc[i],"\t",results$Nv[i],"\t",results$Pn[i],"\t|\t",results$Pu[i],"\t",results$Qp[i],"\t",results$U[i],"\t\t",results$Pz[i],"\t|\t",results$XYZmm1[i],"\t",results$XYZmm2[i],"\t",results$XYZmm3[i],"\n")
	}
    }

}


