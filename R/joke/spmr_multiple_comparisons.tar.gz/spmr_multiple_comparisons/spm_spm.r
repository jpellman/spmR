spm_spm <- function (SPM)                                                                     
{                                                                                  
    xX <- SPM$xX                                                                   
    nScan <- nrow(xX$X)                                                            
    nBeta <- ncol(xX$X)                                                            
    xM <- SPM$xM                                                                   
    if (!is.list(xX$K)) {
        xX$K <- 1                                                                  
    }                                                                              
    xVi <- SPM$xVi                                                                 
    if (!is.null(SPM$xVi$V)) {                                                     
        V <- SPM$xVi$V
    }                                                                              
    else {
        V <- NULL
    }                                                                              
    if (!is.null(V)) {
        done <- TRUE                                                               
        out <- svd(V)
        s <- diag(1/sqrt(out$d))
        W <- out$u %*% s %*% t(out$u)
        idx <- which(abs(W) < 1e-06)
        W[idx] <- 0
        xX$W <- W
    }
    else {
        done <- FALSE
        W <- diag(nScan)
    }
    xX$xKXs <- spm_sp("Set", spm_filter(xX$K, W %*% xX$X))
    xX$pKX <- spm_sp("x-", xX$xKXs)
    erdf <- spm_SpUtil("trRV", xX$xKXs)
    if (!done) {
        Fcname <- "effects of interest"
        iX0 <- c(SPM$xX$iB, SPM$xX$iG)
        xCon <- spm_FcUtil("set", name = Fcname, STAT = "F", 
            set_action = "iX0", value = iX0, sX = xX$xKXs)
        X1o <- spm_FcUtil("X1o", Fc = xCon, sX = xX$xKXs)
        Hsqr <- spm_FcUtil("hsqr", Fc = xCon, sX = xX$xKXs)
        trRV <- spm_SpUtil("trRV", xX$xKXs)
        trMV <- spm_SpUtil("trMV", X1o)
        UFp <- defaults.stats.fmri.ufp
        UF <- qf(UFp, trMV, trRV, lower.tail = FALSE)
    }
    DIM <- dim(SPM$SPMR$VY)[1:3]
    xdim <- DIM[1]
    ydim <- DIM[2]
    zdim <- DIM[3]
    MAXRES <- defaults.stats.maxres
    nSres <- min(nScan, MAXRES)
    if (done) {
        VM <- array(0, dim = DIM)
        Vbeta <- vector("list", length = nBeta)
        for (b in 1:nBeta) {
            Vbeta[[b]] <- array(NA, dim = DIM)
        }
        VResMS <- array(NA, dim = DIM)
        VresI <- vector("list", length = nSres)
        for (i in 1:nSres) {
            VresI[[i]] <- array(NA, dim = DIM)
        }
    }
    CY <- matrix(0, nrow = nScan, ncol = nScan)
    Cy <- matrix(0, nrow = nScan, ncol = nScan)
    EY <- numeric(nScan)
    if (SPM$SPMR$verbose) 
        cat("Estimating parameters:\n")
    Q <- 0
    s <- 0
    for (z in 1:zdim) {
        if (SPM$SPMR$verbose) 
            cat("Plane: ", z, sep = "")
        YY <- matrix(SPM$SPMR$VY[, , z, ], nrow = nScan, byrow = TRUE)
        YY <- YY * SPM$SPMR$VY$scl.slope * SPM$xGX$gSF[1]
        Cm <- rep(TRUE, ncol(YY))
        for (i in 1:nScan) {
            idx <- which(YY[i, ] < SPM$xM$TH[i])
            Cm[idx] <- FALSE
        }
        idx <- which(apply(YY[, Cm, drop = FALSE], MARGIN = 2, 
            function(x) {
                all(x[1] == x)
            }))
        if (length(idx) > 0 && SPM$SPMR$verbose) {
            cat(" Constant voxels removed: ", length(idx), sep = "")
        }
        Cm[Cm][idx] <- FALSE
        YY <- YY[, Cm, drop = FALSE]
        S <- sum(Cm)
        Q <- Q + S
        if (done) {
            VM[, , z][Cm] <- 1
        }
        if (SPM$SPMR$verbose) 
            cat(" Voxels selected: ", S, sep = "")
        if (S > 0) {
            KWY <- spm_filter(xX$K, W %*% YY)
            beta <- xX$pKX %*% KWY
            res <- spm_sp("r", xX$xKXs, KWY)
            ResSS <- colSums(res^2)
            rm(KWY)
            if (!done) {
                F <- (colSums((Hsqr %*% beta)^2)/trMV)/(ResSS/trRV)
                idx <- which(F > UF)
                q <- length(idx)
                cat("\nvoxels over UF threshold: ", q, "\n")
                if (q > 0) {
                  s <- s + q
                  q <- diag(sqrt(trRV/ResSS[idx]))
                  if (length(idx)==1){q <- sqrt(trRV/ResSS[idx])}
                  YY <- YY[, idx, drop = FALSE] %*% q
                  Cy <- Cy + tcrossprod(YY)
                }
            }
            if (done) {
                for (b in 1:nBeta) {
                  Vbeta[[b]][, , z][Cm] <- beta[b, ]
                }
                VResMS[, , z][Cm] <- ResSS
            }
        }
        if (done) {
            CY <- CY + YY %*% t(YY)
            EY <- EY + rowSums(YY)
        }
        if (SPM$SPMR$verbose) 
            cat("...done.\n")
    }
    if (SPM$SPMR$verbose) 
        cat("done\n")
    if (done) {
        CY <- CY/Q
        EY <- EY/Q
        CY <- CY - EY %*% t(EY)
    }
    else {
        stopifnot(s > 0)
        if (SPM$SPMR$verbose) 
            cat("Temporal non-sphericity (over voxels) ... ReML estimation\n")
        Cy <- Cy/s
        if (is.list(SPM$xX$K)) {
            Xp <- cbind(xX$X, xX$K[[1]]$X0)
            V <- spm_reml(Cy, Xp, SPM$xVi$Vi, verbose = SPM$SPMR$verbose)
            h <- attr(V, "h")
        }
        else {
            V <- spm_reml(Cy, xX$X, xVi$Vi, verbose = SPM$SPMR$verbose)
            h <- attr(V, "h")
        }
        V <- V * nScan/sum(diag(V))
        xVi$h <- h
        xVi$V <- V
        xVi$Cy <- Cy
        SPM$xVi <- xVi
        out <- spm_spm(SPM)
        return(out)
    }
    xX$V <- spm_filter(xX$K, spm_filter(xX$K, W %*% V %*% t(W)))
    trRV <- spm_SpUtil("trRV", xX$xKXs, xX$V)
    xX$trRV <- trRV
    xX$Bcov <- xX$pKX %*% xX$V %*% t(xX$pKX)
    VResMS <- VResMS * 1/xX$trRV
    SPM$Vbeta <- Vbeta
    SPM$VResMS <- VResMS
    SPM$VM <- VM
    SPM$xVi <- xVi
    SPM$xVi.CY <- CY
    SPM$xX <- xX
    SPM$xM <- xM
    SPM$xCon <- list()
    SPM
}
