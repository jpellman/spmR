path <- "~/Documents/Uni/Onderzoek/spmR/spmr_multiple_comparisons/"
source(paste(path,"spm_ECdensity.r",sep=""))
source(paste(path,"spm_P_RF.r",sep=""))
source(paste(path,"spm_resels_vol.r",sep=""))
source(paste(path,"spm_u.r",sep=""))
source(paste(path,"spm_uc_Bonf.r",sep=""))
source(paste(path,"spm_uc.r",sep=""))
source(paste(path,"spm_uc_RF.r",sep=""))
source(paste(path,"spm_uc_peakFDR.r",sep=""))
source(paste(path,"spm_uc_clusterFDR.r",sep=""))
source(paste(path,"spm_uc_RF.r",sep=""))
source(paste(path,"spm_getSPM.r",sep=""))
source(paste(path,"spm_bwlabel.r",sep=""))
source(paste(path,"spm_get_lm.r",sep=""))
source(paste(path,"spm_max.r",sep=""))
source(paste(path,"spm_list.r",sep=""))
source(paste(path,"spm_table.r",sep=""))

## VOORAF
# SPMr laten lopen op auditory



# op basis van tmap
SPM$xCon[[1]]$Vspm <-nifti.image.read("/home/joke/Documents/Uni/Onderzoek/spmR/SPM/spmT_0001.img")[,,,1]
SPM$XYZ <- array(NA,dim=c(dim(SPM$xCon[[1]]$Vspm)[1:3],3))
for(m in 1:dim(SPM$xCon[[1]]$Vspm)[1]){
  for(n in 1:dim(SPM$xCon[[1]]$Vspm)[2]){
    for(o in 1:dim(SPM$xCon[[1]]$Vspm)[3]){
      SPM$XYZ[m,n,o,] <- c(m,n,o)}}}
SPM$VM <- ifelse(SPM$xCon[[1]]$Vspm==0,0,1)
SPM$S <- sum(ifelse(SPM$xCon[[1]]$Vspm!=0,1,0))

# op basis van hdr
IMG <- nifti.image.read("/home/joke/Documents/Uni/Onderzoek/spmR/auditory.nii.gz")
SPM$M <- IMG$qto.xyz

# andere
SPM$df <- c(1,73) #vrijheidsgraden
SPM$FWHM <- c(4.8044,4.8076,4.1686) 

# parameters
SPM$pm <- 0.05
SPM$n <- 1
SPM$k <- 0
SPM$xCon[[1]]$STAT <- 'T'
SPM$thr <- 'RF'
SPM$Num <- 3
SPM$Dis <- 8


## INFERENTIE
SPM$xVol$R <- spm_resels_vol(SPM$VM,SPM$FWHM)

SPM <- spm_getSPM(SPM)
SPM <- spm_list(SPM)
spm_table(SPM)




